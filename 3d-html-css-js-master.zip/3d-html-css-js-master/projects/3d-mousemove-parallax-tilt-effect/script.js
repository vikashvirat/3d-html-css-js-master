VanillaTilt.init(document.querySelectorAll(".box"), {
    max: 25,
    speed: 400
});
